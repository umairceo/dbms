import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class CSVReader {
    private Map<String, int[]> data;

    public CSVReader(String filename) {
        data = new HashMap<>();
        loadCSV(filename);
    }

    private void loadCSV(String filename) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String headerLine = reader.readLine(); // Skip the header
            String[] columns = headerLine.split(",");

            for (String column : columns) {
                data.put(column.trim(), new int[]{});
            }

            String line;
            while ((line = reader.readLine()) != null) {
                String[] values = line.split(",");
                for (int i = 0; i < values.length; i++) {
                    String column = columns[i].trim();
                    int[] columnValues = data.get(column);
                    int[] newValues = new int[columnValues.length + 1];
                    System.arraycopy(columnValues, 0, newValues, 0, columnValues.length);
                    newValues[columnValues.length] = Integer.parseInt(values[i].trim());
                    data.put(column, newValues);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public int[] getColumn(String columnName) {
        return data.get(columnName);
    }

    public void bubbleSort(String columnName) {
        int[] columnValues = data.get(columnName);

        for (int i = 0; i < columnValues.length - 1; i++) {
            for (int j = 0; j < columnValues.length - i - 1; j++) {
                if (columnValues[j] > columnValues[j + 1]) {
                    // Swap values
                    int temp = columnValues[j];
                    columnValues[j] = columnValues[j + 1];
                    columnValues[j + 1] = temp;
                }
            }
        }
    }

    public void selectionSort(String columnName) {
        int[] columnValues = data.get(columnName);

        for (int i = 0; i < columnValues.length - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < columnValues.length; j++) {
                if (columnValues[j] < columnValues[minIndex]) {
                    minIndex = j;
                }
            }
            // Swap values
            int temp = columnValues[minIndex];
            columnValues[minIndex] = columnValues[i];
            columnValues[i] = temp;
        }
    }

    public void insertionSort(String columnName) {
        int[] columnValues = data.get(columnName);

        for (int i = 1; i < columnValues.length; i++) {
            int key = columnValues[i];
            int j = i - 1;

            while (j >= 0 && columnValues[j] > key) {
                columnValues[j + 1] = columnValues[j];
                j--;
            }
            columnValues[j + 1] = key;
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        CSVReader csvReader = new CSVReader("C:\\Users\\hp\\IdeaProjects\\Daa Project\\src\\Wholesalev.csv");
        boolean shouldContinue = true;

        while (shouldContinue) {
            System.out.println("Select a sorting algorithm:");
            System.out.println("1. Bubble Sort");
            System.out.println("2. Selection Sort");
            System.out.println("3. Insertion Sort");
            System.out.println("4. Exit");
            System.out.println("\n\nENTER CHOICE: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            if (choice == 1) {
                System.out.println("ENTER Column Name: ");
                String choice1 = scanner.nextLine();
                csvReader.bubbleSort(choice1);
            } else if (choice == 2) {
                System.out.println("ENTER Column Name: ");
                String choice1 = scanner.nextLine();
                csvReader.selectionSort(choice1);
            } else if (choice == 3) {
                System.out.println("ENTER Column Name: ");
                String choice1 = scanner.nextLine();
                csvReader.insertionSort(choice1);
            } else if (choice == 4) {
                shouldContinue = false;
                continue;
            } else {
                System.out.println("Invalid choice. Please try again.");
                continue;
            }

            int[] channelValues = csvReader.getColumn("Channel");
            int[] regionValues = csvReader.getColumn("Region");
            int[] freshValues = csvReader.getColumn("Fresh");
            int[] milkValues = csvReader.getColumn("Milk");
            printValues(channelValues, regionValues, freshValues, milkValues);
        }
    }

    private static void printValues(int[] channelValues, int[] regionValues, int[] freshValues, int[] milkValues) {
        for (int i = 0; i < channelValues.length; i++) {
            System.out.println("Channel: " + channelValues[i]);
            System.out.println("Region: " + regionValues[i]);
            System.out.println("Fresh: " + freshValues[i]);
            System.out.println("Milk: " + milkValues[i]);
            System.out.println();
        }
    }
}
